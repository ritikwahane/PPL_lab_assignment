#include <stdlib.h>
void main() {
	exit(0);
}
