void function(int a, int b, int c) {
	char buffer1[5];
	char buffer2[10];
}
void main() {
	function(1,2,3);
}
