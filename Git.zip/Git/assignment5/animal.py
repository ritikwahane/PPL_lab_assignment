class Animals:
    def __init__(self, legs = 4, eyes = 2):
        self.legs = legs
        self.eyes = eyes

class herbivores(Animals):
	def food(self):
        	print("Plants and fruits")
    
class horse(herbivores):
	def sound(self):
                print("Whinny")


class cow(herbivores):
	def sound(self):
		print("Moo")

class goat(herbivores):
	def sound(self):
		print("Bleat")
        
class zebra(herbivores):
	def sound(self):
                print("Whinny")

class carnivores(Animals):
	def food(self):
        	print("Meat")
    
class lion(carnivores):
	def sound(self):
    	    print("Roar")

class wolf(carnivores):
	def sound(self):
  		print("Howl")

class hyena(carnivores):
		def sound(self):
        	        print("Laugh")

class omnivores(Animals):
	def food(self):
		print("Veg as well as meat")

	
class dog(omnivores):
	def sound(self):
      		print("Bark")

class bear(omnivores):
	def sound(self):
                print("Roar Growl")

class cat(omnivores):
	def sound(self):
                print("Meow")


p1 = Animals()
p2 = dog()
print("dog's food")
p2.food()
print("dog's sound")
p2.sound()
print("No. of legs and eyes:")
print(p2.legs)
print(p2.eyes)
