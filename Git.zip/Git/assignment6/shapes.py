import turtle
import time

window = turtle.getscreen()
t = turtle.Turtle()            #returns new object turtle


class shape:
    def __init__(self, sides = 0, length = 0) :
        self.sides = sides
        self.length = length


class polygon(shape):
    def info(self):
    	pass
        
class square(polygon):
    def show(self):
        t.forward(self.length)
        t.right(90)
        t.forward(self.length)
        t.right(90)
        t.forward(self.length)
        t.right(90)
        t.forward(self.length)
        t.right(90)
    
class pentagon(polygon):
    def show(self):
        for i in range(5):
           t.forward(self.length) 
           t.right(72) 
    
class hexagon(polygon):
    def show(self):
        for i in range(6):
           t.forward(self.length) 
           t.right(60)

class octagon(polygon):
    def show(self):
        for i in range(8):
           t.forward(self.length) 
           t.right(45)
    
class star(polygon):
    def show(self):
        for i in range(5):
           t.forward(self.length) 
           t.right(144)
    
class triangle(polygon):
    def show(self):
        t.forward(self.length) 
        t.left(120)
        t.forward(self.length)
        t.left(120)
        t.forward(self.length)
    

o = star(5, 200)
o.info()
o.show()

time.sleep(2)


