for x in "car":
	print(x)
#class Pet(object):
#  def my_method(self):
#     print("I am a Cat")
#cat = Pet()
#cat.my_method()

fruits = ["apple", "banana", "cherry"]
for x in fruits:
#  print(x)
#  if(x == "banana"):
#  	break
   if(x == "banana"):
   	break
   print(x)

for i in range(6):
	print(i)

class person:
	def __init__(self, name, age):
		self.name = name
		self.age = age

	def myname(self):
		print("Hello My name is " + self.name)

p1 = person("John", 79)
p1.myname()
print(p1.name)
print(p1.age)
print()
print()


class Person:
  def __init__(mysillyobject, name, age):
    mysillyobject.name = name
    mysillyobject.age = age

  def myfunc(abc):
    print("Hello my name is " + abc.name)

p1 = Person("John", 36)
p1.myfunc()


class person1:
	def __init__(self, fname, lname):
		self.firstname = fname
		self.lastname = lname

	def printname(self):
		print(self.firstname, self.lastname)


x = person1("Kevin", "Roy")
x.printname()



class student(person1):
	def __init__(self, fname, lname, year):
		super().__init__(fname, lname)
		self.graduationyear = 2022


	def welcome(self):
		print("Welcome" + self.firstname + self.lastname + "to the class of" + self.graduationyear)


x = student("Mike", "Thomas", 2019)
x.printname()	



x = student("Mike", "Olsen", 2019)
x.welcome(2020)
