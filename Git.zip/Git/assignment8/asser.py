x = "hello"

if not type(x) is int:
  raise TypeError("Only integers are allowed")
pritnt()
print()

x = -1

if x < 0:
  raise Exception("Sorry, no numbers below zero")

