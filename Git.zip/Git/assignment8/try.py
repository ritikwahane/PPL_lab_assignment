try:
  print(x)
except:
  print("An exception occurred")

print()
print()



try:
	print(x)
except NameError:
	print("Variable x is not Defined")
except:
	print()
	print()


try:
  print("Hello")
except:
  print("Something went wrong")
else:
  print("Nothing went wrong")
print()
print()

try:
  print(x)
except:
  print("Something went wrong")
finally:
  print("The 'try except' is finished")

