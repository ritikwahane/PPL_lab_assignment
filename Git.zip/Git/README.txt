
Assignment1-
gcc -c -fdump-tree-gimple filename.c

Assignment2-
1.gcc -Wall -save-temps filename.c -o filename
2.objdump -l -d -r filename.o

Assignment3-
1.gcc filename.c -fdump-tree-cfg-graph
2.gcc filename.c -fdump-tree-all-graph

Assignment4-
g++ -g filename.cpp -o filename
gdb filename





















