teacher_sub(t1, ppl).
teacher_sub(t2, dld).
teacher_sub(t3, dtl).
teacher_sub(t4, dsa).
teaher_sub(t5, math).
teacher_sub(t6, plevh).
teacher_sub(t7, dsgt). 

subject(math_dept, math).
subject(comp_dept, dsa).
subject(comp_dept, ppl).
subject(comp_dept, dld).
subject(comp_dept, dtl).
subject(applied_science, plevh). 
subject(comp_dept, dsgt).

student(comp_dept, s1).
student(comp_dept, s2). 

faculty(D, F) :- teachers_sub(F, S) , subject(D, S).
enrolled_sub(ST, SB) :-  student(D, ST) , subject(D, SB).
studies_under(S,F) :- subject(D,SB) , student(D,S) , teacher_sub(F,SB).





